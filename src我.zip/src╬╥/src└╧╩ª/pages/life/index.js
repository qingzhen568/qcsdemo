import React,{Component} from 'react';
class Life extends Component{
	render(){
		return (
			<h1>居家生活</h1>
		)
	}
}

export default Life;