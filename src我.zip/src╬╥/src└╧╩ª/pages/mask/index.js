import React,{Component} from 'react';
class Mask extends Component{
	render(){
		return (
			<h1>面膜中心</h1>
		)
	}
}

export default Mask;