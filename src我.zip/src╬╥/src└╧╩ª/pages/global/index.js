import React,{Component} from 'react';
class Global extends Component{
	render(){
		return (
			<h1>购全球</h1>
		)
	}
}

export default Global;