import React,{Component} from 'react'
import './index.scss'
//引入头部
import MaskTop from '../../components/mask/maskTop/maskTop'
class Mask extends Component{
    componentWillUnmount(){
        this.setState=(state,callback)=>{
            return
        }
    }
    render(){
        return (
            <div id="mask">
                {/* 面膜中心的所有组件都放在这里 */}
                <MaskTop />
            </div>
        )
    }
}

export default Mask;