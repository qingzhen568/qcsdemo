import React,{Component} from 'react'
import './maskTop.scss'
import axios from 'axios'

export default class MaskTop extends Component{
    constructor(){
        super();
        this.state={
            maskTopImg:[],
        }
    }
    componentDidMount(){
        axios.get('/tms/aladdin/get?code=Mask_center_banner_index_1')
        .then((resp)=>{
            console.log('maskTop',resp.data.data.datas)
            this.setState({
                maskTopImg: resp.data.data.datas[1].image_url
            })
        })
    }
    render(){
        return (
            <div id="maskTop">
                <img src={this.state.maskTopImg} alt="全球面膜尖货" />
            </div>
        )
    }
}